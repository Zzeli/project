$(function(){
	 var lis=$('nav li');
      console.log(lis)

      var index=[1,2,3,4,5];
      console
      	 index.each(function(j){  
      	 })


      lis.each(function(i){


			  	if(index[i]==i){

			  	 lis[i].addClass('active')

			  	}


      })

     


     $('.navbar-nav li').not(".active").find('a').mouseover(function(){
            $(this).css({color:'#fff'})
            $(this).prev('.nav-animate').css({display:'block',zIndex:'-1'})
        })
        $('.navbar-nav li').not(".active").find('a').mouseout(function(){
            $(this).css({color:'#fff'})
            $(this).prev('.nav-animate').css({display:'none',zIndex:'-1'})
        })


	
})